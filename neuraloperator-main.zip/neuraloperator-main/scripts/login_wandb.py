from neuralop.utils import wandb_login
wandb_login()
