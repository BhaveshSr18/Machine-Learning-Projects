from .fno import TFNO, TFNO1d, TFNO2d, TFNO3d
from .fno import FNO, FNO1d, FNO2d, FNO3d
from .fno import SFNO
from .uno import UNO
from .fnogno import FNOGNO
from .gino import GINO
from .base_model import get_model
