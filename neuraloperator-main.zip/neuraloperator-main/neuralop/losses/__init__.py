from .data_losses import LpLoss, H1Loss
from .equation_losses import BurgersEqnLoss, ICLoss
from .meta_losses import WeightedSumLoss