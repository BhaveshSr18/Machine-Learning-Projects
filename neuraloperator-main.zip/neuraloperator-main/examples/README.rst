Gallery of examples
===================

.. contents:: **Contents**
    :local:
    :depth: 1

